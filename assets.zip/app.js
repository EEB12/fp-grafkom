document.write('welcome to my app');
console.log('app loaded');